/*var BASE_URL = location.origin + (location.port && ":" + location.port) + "/";*/
var BASE_URL = location.origin + "/";
//var API_URL = BASE_URL + "public/api/";
var API_URL = BASE_URL + "api/";
//var SITE_URL = BASE_URL + 'public/';
var SITE_URL = BASE_URL + '/';
